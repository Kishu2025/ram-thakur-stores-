"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { productData } from "@/lib/product-data"

export function CategorySection({ category, isActive }) {
  const [subcategory, setSubcategory] = useState("All")
  const [filteredProducts, setFilteredProducts] = useState([])

  useEffect(() => {
    // Reset subcategory when category changes
    setSubcategory("All")

    // Filter products based on selected category and subcategory
    let filtered = productData[category.id] || []

    if (subcategory !== "All") {
      filtered = filtered.filter((product) => {
        if (category.id === "accessories") {
          return product.type === subcategory
        }
        return product.brand === subcategory
      })
    }

    setFilteredProducts(filtered)
  }, [category.id, subcategory])

  return (
    <div>
      {/* Subcategories */}
      <AnimatePresence mode="wait">
        {isActive && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="overflow-x-auto py-4 flex space-x-2"
          >
            {category.subcategories.map((sub) => (
              <Button
                key={sub}
                variant={subcategory === sub ? "default" : "outline"}
                size="sm"
                onClick={() => setSubcategory(sub)}
                className="whitespace-nowrap"
              >
                {sub}
              </Button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Products */}
      <AnimatePresence mode="wait">
        <motion.div
          key={category.id + subcategory}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="grid grid-cols-2 gap-4"
        >
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product, idx) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Link href={`/products/${category.id}/${product.id}`}>
                  <ProductCard product={product} />
                </Link>
              </motion.div>
            ))
          ) : (
            <p className="col-span-2 text-center py-8 text-muted-foreground">No products found in this category.</p>
          )}
        </motion.div>
      </AnimatePresence>

      {/* View all link */}
      {filteredProducts.length > 0 && (
        <div className="mt-6 text-center">
          <Button asChild variant="outline">
            <Link href={`/products/${category.id}`}>View All {category.name}</Link>
          </Button>
        </div>
      )}
    </div>
  )
}


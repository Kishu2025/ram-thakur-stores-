"use client"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Heart, ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"

export function ProductCard({ product }) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
      <Card
        className="h-full overflow-hidden transition-shadow border-border"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardHeader className="p-0 relative aspect-square">
          <div className="absolute top-2 right-2 z-10">
            <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full bg-background/80 backdrop-blur-sm">
              <Heart className="h-4 w-4" />
            </Button>
          </div>
          <div className="relative h-full w-full">
            <motion.div
              animate={{ scale: isHovered ? 1.05 : 1 }}
              transition={{ duration: 0.3 }}
              className="h-full w-full"
            >
              <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
            </motion.div>
          </div>
        </CardHeader>
        <CardContent className="p-3">
          <div className="text-xs text-muted-foreground mb-1">{product.brand}</div>
          <h3 className="font-medium leading-tight line-clamp-2">{product.name}</h3>
          <p className="mt-2 font-bold">₹{product.price.toLocaleString()}</p>
        </CardContent>
        <CardFooter className="p-3 pt-0">
          <Button variant="outline" size="sm" className="w-full">
            <ShoppingCart className="h-4 w-4 mr-2" /> Add to Cart
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}


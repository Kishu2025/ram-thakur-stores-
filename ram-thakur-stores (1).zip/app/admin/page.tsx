"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Plus,
  Edit,
  Trash2,
  ChevronDown,
  ChevronUp,
  Search,
  Smartphone,
  Tablet,
  Laptop,
  Headphones,
  Package,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"

// Sample products for admin management
const initialProducts = [
  { id: 1, name: "Realme 13 Pro+ 5G", price: 35999, brand: "Realme", category: "mobile", stock: 12 },
  { id: 2, name: "Vivo V30", price: 32999, brand: "Vivo", category: "mobile", stock: 8 },
  { id: 3, name: "Oppo Reno 11", price: 29999, brand: "Oppo", category: "mobile", stock: 15 },
  { id: 4, name: "Samsung Galaxy S24", price: 79999, brand: "Samsung", category: "mobile", stock: 5 },
  { id: 5, name: "iPad Pro 11", price: 79999, brand: "Apple", category: "tablets", stock: 7 },
  { id: 6, name: "Samsung Tab S9", price: 65999, brand: "Samsung", category: "tablets", stock: 4 },
  { id: 7, name: "MacBook Air M2", price: 99999, brand: "Apple", category: "laptops", stock: 3 },
  { id: 8, name: "Dell XPS 13", price: 89999, brand: "Dell", category: "laptops", stock: 6 },
  { id: 9, name: "AirPods Pro", price: 24999, brand: "Apple", category: "accessories", stock: 20 },
  { id: 10, name: "Galaxy Buds 2", price: 9999, brand: "Samsung", category: "accessories", stock: 25 },
]

const categories = [
  { id: "mobile", name: "Mobile Phones", icon: Smartphone },
  { id: "tablets", name: "Tablets", icon: Tablet },
  { id: "laptops", name: "Laptops", icon: Laptop },
  { id: "accessories", name: "Accessories", icon: Headphones },
]

const brands = ["Realme", "Vivo", "Oppo", "Samsung", "Apple", "Dell", "HP", "Lenovo", "OnePlus"]

export default function AdminDashboard() {
  const [products, setProducts] = useState(initialProducts)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [newProduct, setNewProduct] = useState({
    name: "",
    price: "",
    brand: "",
    category: "",
    stock: "",
  })
  const [editingProduct, setEditingProduct] = useState(null)

  // Filter products based on search and category
  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  // Handle adding a new product
  const handleAddProduct = () => {
    const productToAdd = {
      id: products.length + 1,
      name: newProduct.name,
      price: Number.parseInt(newProduct.price),
      brand: newProduct.brand,
      category: newProduct.category,
      stock: Number.parseInt(newProduct.stock),
    }

    setProducts([...products, productToAdd])

    // Reset form
    setNewProduct({
      name: "",
      price: "",
      brand: "",
      category: "",
      stock: "",
    })
  }

  // Handle updating a product
  const handleUpdateProduct = () => {
    if (!editingProduct) return

    const updatedProducts = products.map((product) => (product.id === editingProduct.id ? editingProduct : product))

    setProducts(updatedProducts)
    setEditingProduct(null)
  }

  // Handle deleting a product
  const handleDeleteProduct = (id) => {
    const updatedProducts = products.filter((product) => product.id !== id)
    setProducts(updatedProducts)
  }

  return (
    <div className="min-h-screen p-4 max-w-7xl mx-auto">
      <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage your products, inventory, and more</p>
      </motion.header>

      <div className="grid gap-6">
        {/* Dashboard overview cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 gap-4 md:grid-cols-4"
        >
          <DashboardCard title="Total Products" value={products.length} icon={Package} />
          <DashboardCard title="Categories" value={categories.length} icon={ChevronDown} />
          <DashboardCard
            title="Low Stock"
            value={products.filter((p) => p.stock < 5).length}
            icon={ChevronDown}
            alert
          />
          <DashboardCard title="Total Stock" value={products.reduce((sum, p) => sum + p.stock, 0)} icon={ChevronUp} />
        </motion.div>

        {/* Product management */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card rounded-lg border border-border p-4"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <h2 className="text-xl font-bold">Product Management</h2>

            <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
              <div className="relative w-full md:w-64">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Dialog>
                <DialogTrigger asChild>
                  <Button className="whitespace-nowrap">
                    <Plus className="h-4 w-4 mr-2" /> Add Product
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                  </DialogHeader>

                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="name">Product Name</Label>
                      <Input
                        id="name"
                        value={newProduct.name}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="price">Price (₹)</Label>
                        <Input
                          id="price"
                          type="number"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="stock">Stock</Label>
                        <Input
                          id="stock"
                          type="number"
                          value={newProduct.stock}
                          onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="brand">Brand</Label>
                      <Select
                        value={newProduct.brand}
                        onValueChange={(value) => setNewProduct({ ...newProduct, brand: value })}
                      >
                        <SelectTrigger id="brand">
                          <SelectValue placeholder="Select brand" />
                        </SelectTrigger>
                        <SelectContent>
                          {brands.map((brand) => (
                            <SelectItem key={brand} value={brand}>
                              {brand}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="category">Category</Label>
                      <Select
                        value={newProduct.category}
                        onValueChange={(value) => setNewProduct({ ...newProduct, category: value })}
                      >
                        <SelectTrigger id="category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">Cancel</Button>
                    </DialogClose>
                    <DialogClose asChild>
                      <Button onClick={handleAddProduct}>Add Product</Button>
                    </DialogClose>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Products table */}
          <div className="border border-border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Brand</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Stock</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <TableRow key={product.id}>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell>
                        {categories.find((c) => c.id === product.category)?.name || product.category}
                      </TableCell>
                      <TableCell>{product.brand}</TableCell>
                      <TableCell className="text-right">₹{product.price.toLocaleString()}</TableCell>
                      <TableCell className={`text-right ${product.stock < 5 ? "text-destructive font-medium" : ""}`}>
                        {product.stock}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon" onClick={() => setEditingProduct(product)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Product</DialogTitle>
                              </DialogHeader>

                              {editingProduct && (
                                <div className="grid gap-4 py-4">
                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-name">Product Name</Label>
                                    <Input
                                      id="edit-name"
                                      value={editingProduct.name}
                                      onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                                    />
                                  </div>

                                  <div className="grid grid-cols-2 gap-4">
                                    <div className="grid gap-2">
                                      <Label htmlFor="edit-price">Price (₹)</Label>
                                      <Input
                                        id="edit-price"
                                        type="number"
                                        value={editingProduct.price}
                                        onChange={(e) =>
                                          setEditingProduct({
                                            ...editingProduct,
                                            price: Number.parseInt(e.target.value),
                                          })
                                        }
                                      />
                                    </div>

                                    <div className="grid gap-2">
                                      <Label htmlFor="edit-stock">Stock</Label>
                                      <Input
                                        id="edit-stock"
                                        type="number"
                                        value={editingProduct.stock}
                                        onChange={(e) =>
                                          setEditingProduct({
                                            ...editingProduct,
                                            stock: Number.parseInt(e.target.value),
                                          })
                                        }
                                      />
                                    </div>
                                  </div>

                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-brand">Brand</Label>
                                    <Select
                                      value={editingProduct.brand}
                                      onValueChange={(value) => setEditingProduct({ ...editingProduct, brand: value })}
                                    >
                                      <SelectTrigger id="edit-brand">
                                        <SelectValue placeholder="Select brand" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {brands.map((brand) => (
                                          <SelectItem key={brand} value={brand}>
                                            {brand}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>

                                  <div className="grid gap-2">
                                    <Label htmlFor="edit-category">Category</Label>
                                    <Select
                                      value={editingProduct.category}
                                      onValueChange={(value) =>
                                        setEditingProduct({ ...editingProduct, category: value })
                                      }
                                    >
                                      <SelectTrigger id="edit-category">
                                        <SelectValue placeholder="Select category" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {categories.map((category) => (
                                          <SelectItem key={category.id} value={category.id}>
                                            {category.name}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                </div>
                              )}

                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">Cancel</Button>
                                </DialogClose>
                                <DialogClose asChild>
                                  <Button onClick={handleUpdateProduct}>Save Changes</Button>
                                </DialogClose>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Delete Product</DialogTitle>
                              </DialogHeader>
                              <p>Are you sure you want to delete this product? This action cannot be undone.</p>
                              <DialogFooter className="mt-4">
                                <DialogClose asChild>
                                  <Button variant="outline">Cancel</Button>
                                </DialogClose>
                                <DialogClose asChild>
                                  <Button variant="destructive" onClick={() => handleDeleteProduct(product.id)}>
                                    Delete
                                  </Button>
                                </DialogClose>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
                      No products found. Try a different search or category.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

function DashboardCard({ title, value, icon: Icon, alert = false }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-4 w-4 ${alert ? "text-destructive" : "text-muted-foreground"}`} />
      </CardHeader>
      <CardContent>
        <div className={`text-2xl font-bold ${alert ? "text-destructive" : ""}`}>{value}</div>
      </CardContent>
    </Card>
  )
}


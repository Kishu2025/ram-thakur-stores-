"use client"

import { useEffect, useRef } from "react"
import { motion, useAnimation } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { Laptop, Phone, ShoppingBag, Watch } from "lucide-react"

import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { BottomNav } from "@/components/bottom-nav"

export default function Home() {
  const controls = useAnimation()
  const bannerRef = useRef(null)

  useEffect(() => {
    controls.start({
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    })

    // Animate banner entry
    setTimeout(() => {
      if (bannerRef.current) {
        bannerRef.current.classList.remove("translate-y-full")
        bannerRef.current.classList.add("translate-y-0")
      }
    }, 1000)
  }, [controls])

  return (
    <main className="flex min-h-screen flex-col items-center bg-background text-foreground">
      {/* Header with mode toggle */}
      <header className="w-full sticky top-0 z-50 flex justify-between items-center p-4 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="text-xl font-bold">Ram Thakur Stores</div>
        <ModeToggle />
      </header>

      {/* Hero section */}
      <motion.section className="w-full px-4 py-8 text-center" initial={{ opacity: 0, y: 20 }} animate={controls}>
        <h1 className="text-3xl font-bold mb-4">Premium Electronics Store</h1>
        <p className="text-muted-foreground mb-6">Your trusted partner for quality electronics and mobile phones</p>
        <Button asChild size="lg" className="mb-8">
          <Link href="/products">Explore Products</Link>
        </Button>
      </motion.section>

      {/* Founder section */}
      <section className="w-full px-4 py-8 bg-muted/30">
        <h2 className="text-2xl font-bold mb-6 text-center">Our Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <motion.div
            className="flex flex-col items-center"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-primary mb-4">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG20250312162026.jpg-RpdlL8375MIGinweZZeTxGqUMXyXuU.jpeg"
                alt="Founder"
                fill
                className="object-cover"
              />
            </div>
            <h3 className="text-xl font-bold">Founder</h3>
            <p className="text-muted-foreground text-center mt-2">
              Visionary leader behind Ram Thakur Stores, passionate about bringing the latest technology to customers.
            </p>
          </motion.div>

          <motion.div
            className="flex flex-col items-center"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-primary mb-4">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG20250209171541.jpg-Hd3vJZxkSpUmKj8DNuagXZrP4UVnwO.jpeg"
                alt="Co-Founder"
                fill
                className="object-cover"
              />
            </div>
            <h3 className="text-xl font-bold">Co-Founder</h3>
            <p className="text-muted-foreground text-center mt-2">
              Tech enthusiast and customer experience expert, ensuring the best service for all customers.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Category preview */}
      <section className="w-full px-4 py-8">
        <h2 className="text-2xl font-bold mb-6 text-center">Discover Our Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {[
            { name: "Mobile Phones", icon: Phone, link: "/products/mobile" },
            { name: "Laptops", icon: Laptop, link: "/products/laptops" },
            { name: "Accessories", icon: ShoppingBag, link: "/products/accessories" },
            { name: "Smartwatches", icon: Watch, link: "/products/smartwatches" },
          ].map((category, index) => (
            <motion.div
              key={index}
              className="flex flex-col items-center border border-border rounded-lg p-4 hover:bg-accent transition-colors"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 * index, duration: 0.5 }}
            >
              <Link href={category.link} className="w-full h-full flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                  <category.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-medium text-center">{category.name}</h3>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Future expansion banner */}
      <div
        ref={bannerRef}
        className="fixed bottom-16 left-0 right-0 bg-primary text-primary-foreground p-4 text-center transform translate-y-full transition-transform duration-500 ease-in-out"
      >
        Currently, offline services are available. In the future, online shopping will be introduced.
      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </main>
  )
}


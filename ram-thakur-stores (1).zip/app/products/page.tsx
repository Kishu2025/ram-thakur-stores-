"use client"

import { useState } from "react"
import { ChevronRight, Smartphone, Tablet, Laptop, Headphones, Watch } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BottomNav } from "@/components/bottom-nav"
import { CategorySection } from "@/components/category-section"

// Define all categories with their subcategories
const categories = [
  {
    id: "mobile",
    name: "Mobile Phones",
    icon: Smartphone,
    subcategories: ["All", "Realme", "Vivo", "Oppo", "Samsung", "Apple", "OnePlus"],
  },
  {
    id: "tablets",
    name: "Tablets",
    icon: Tablet,
    subcategories: ["All", "Apple", "Samsung", "Lenovo", "Xiaomi"],
  },
  {
    id: "laptops",
    name: "Laptops",
    icon: Laptop,
    subcategories: ["All", "Apple", "Dell", "HP", "Lenovo", "Asus"],
  },
  {
    id: "accessories",
    name: "Accessories",
    icon: Headphones,
    subcategories: ["All", "Headphones", "Chargers", "Cases", "Screen Protectors", "Power Banks"],
  },
  {
    id: "smartwatches",
    name: "Smartwatches",
    icon: Watch,
    subcategories: ["All", "Apple", "Samsung", "Fitbit", "Garmin", "Amazfit"],
  },
]

export default function ProductsPage() {
  const [activeCategory, setActiveCategory] = useState("mobile")

  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 border-b border-border flex justify-between items-center">
        <h1 className="text-xl font-bold">Products</h1>
        <Link href="/">
          <Button variant="ghost" size="sm">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </Link>
      </header>

      {/* Main content */}
      <main className="p-4">
        {/* Categories tabs */}
        <Tabs defaultValue="mobile" onValueChange={setActiveCategory} className="mb-6">
          <TabsList className="w-full grid grid-cols-5 h-auto">
            {categories.map((cat) => (
              <TabsTrigger
                key={cat.id}
                value={cat.id}
                className="flex flex-col items-center py-2 data-[state=active]:bg-primary/10"
              >
                <cat.icon className="h-5 w-5 mb-1" />
                <span className="text-xs">{cat.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {/* Category content */}
          {categories.map((cat) => (
            <TabsContent key={cat.id} value={cat.id} className="mt-4">
              <CategorySection category={cat} isActive={activeCategory === cat.id} />
            </TabsContent>
          ))}
        </Tabs>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}


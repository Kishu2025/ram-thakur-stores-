"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"

import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ProductCard } from "@/components/product-card"
import { productData } from "@/lib/product-data"

// Map category IDs to display names
const categoryNames = {
  mobile: "Mobile Phones",
  tablets: "Tablets",
  laptops: "Laptops",
  accessories: "Accessories",
  smartwatches: "Smartwatches",
}

export default function CategoryPage() {
  const params = useParams()
  const category = params.category as string
  const [products, setProducts] = useState([])

  useEffect(() => {
    // Get products for this category
    const categoryProducts = productData[category] || []
    setProducts(categoryProducts)
  }, [category])

  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 border-b border-border flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/products">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">{categoryNames[category] || "Products"}</h1>
        </div>
      </header>

      {/* Main content */}
      <main className="p-4">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2">All {categoryNames[category]}</h2>
          <p className="text-muted-foreground">Browse our collection of {categoryNames[category].toLowerCase()}</p>
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.length > 0 ? (
            products.map((product, idx) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Link href={`/products/${category}/${product.id}`}>
                  <ProductCard product={product} />
                </Link>
              </motion.div>
            ))
          ) : (
            <p className="col-span-full text-center py-8 text-muted-foreground">No products found in this category.</p>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}


"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Heart, ShoppingCart, Share2, Star } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"

import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { productData } from "@/lib/product-data"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProductCard } from "@/components/product-card"

export default function ProductDetailPage() {
  const params = useParams()
  const category = params.category as string
  const productId = params.id as string

  const [product, setProduct] = useState(null)
  const [selectedImage, setSelectedImage] = useState(0)
  const [relatedProducts, setRelatedProducts] = useState([])

  // Generate multiple placeholder images for the product gallery
  const productImages = [
    "/placeholder.svg?height=600&width=600",
    "/placeholder.svg?height=600&width=600",
    "/placeholder.svg?height=600&width=600",
    "/placeholder.svg?height=600&width=600",
  ]

  useEffect(() => {
    // Find the product
    const categoryProducts = productData[category] || []
    const foundProduct = categoryProducts.find((p) => p.id === productId)

    if (foundProduct) {
      setProduct(foundProduct)

      // Get related products (same brand or category, excluding current product)
      const related = categoryProducts
        .filter((p) => p.id !== productId)
        .filter((p) => p.brand === foundProduct.brand || true) // Include all for now to ensure we have items
        .slice(0, 4)

      setRelatedProducts(related)
    }
  }, [category, productId])

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading product...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 border-b border-border flex justify-between items-center">
        <div className="flex items-center">
          <Link href={`/products/${category}`}>
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">Product Details</h1>
        </div>
        <Button variant="ghost" size="icon">
          <Share2 className="h-4 w-4" />
        </Button>
      </header>

      {/* Main content */}
      <main className="p-4">
        {/* Product gallery */}
        <div className="mb-6">
          <div className="relative aspect-square rounded-lg overflow-hidden mb-4 border border-border">
            <Image
              src={productImages[selectedImage] || "/placeholder.svg"}
              alt={product.name}
              fill
              className="object-cover"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2">
            {productImages.map((img, idx) => (
              <button
                key={idx}
                className={`relative w-20 h-20 rounded-md overflow-hidden border-2 ${selectedImage === idx ? "border-primary" : "border-border"}`}
                onClick={() => setSelectedImage(idx)}
              >
                <Image
                  src={img || "/placeholder.svg"}
                  alt={`${product.name} view ${idx + 1}`}
                  fill
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product info */}
        <div className="mb-6">
          <div className="flex justify-between items-start mb-2">
            <div>
              <h2 className="text-2xl font-bold">{product.name}</h2>
              <p className="text-muted-foreground">{product.brand}</p>
            </div>
            <Button variant="outline" size="icon" className="rounded-full">
              <Heart className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex items-center gap-1 mb-4">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`h-4 w-4 ${star <= 4 ? "fill-primary text-primary" : "text-muted-foreground"}`}
              />
            ))}
            <span className="text-sm text-muted-foreground ml-1">(24 reviews)</span>
          </div>

          <p className="text-3xl font-bold mb-4">₹{product.price.toLocaleString()}</p>

          <p className="text-muted-foreground mb-6">{product.description}</p>

          <div className="flex gap-4 mb-6">
            <Button className="flex-1">
              <ShoppingCart className="h-4 w-4 mr-2" /> Add to Cart
            </Button>
            <Button variant="outline" className="flex-1">
              Buy Now
            </Button>
          </div>
        </div>

        {/* Product details tabs */}
        <Tabs defaultValue="specifications" className="mb-8">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="specifications" className="mt-4">
            <div className="space-y-2">
              <div className="flex justify-between py-2 border-b border-border">
                <span className="font-medium">Brand</span>
                <span>{product.brand}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="font-medium">Model</span>
                <span>{product.name}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="font-medium">Warranty</span>
                <span>1 Year</span>
              </div>
              <div className="flex justify-between py-2 border-b border-border">
                <span className="font-medium">In Box</span>
                <span>Device, Charger, Manual</span>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="features" className="mt-4">
            <ul className="space-y-2 list-disc list-inside">
              <li>Premium build quality</li>
              <li>High-performance specifications</li>
              <li>Long battery life</li>
              <li>Fast charging support</li>
              <li>Latest software updates</li>
            </ul>
          </TabsContent>

          <TabsContent value="reviews" className="mt-4">
            <div className="space-y-4">
              <div className="p-4 border border-border rounded-lg">
                <div className="flex items-center gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-3 w-3 ${star <= 5 ? "fill-primary text-primary" : "text-muted-foreground"}`}
                    />
                  ))}
                </div>
                <p className="font-medium mb-1">Excellent product!</p>
                <p className="text-sm text-muted-foreground mb-2">
                  This is an amazing product with great features and performance. Highly recommended!
                </p>
                <p className="text-xs text-muted-foreground">Rahul S. - 2 weeks ago</p>
              </div>

              <div className="p-4 border border-border rounded-lg">
                <div className="flex items-center gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-3 w-3 ${star <= 4 ? "fill-primary text-primary" : "text-muted-foreground"}`}
                    />
                  ))}
                </div>
                <p className="font-medium mb-1">Good value for money</p>
                <p className="text-sm text-muted-foreground mb-2">
                  Great product for the price. Battery life could be better though.
                </p>
                <p className="text-xs text-muted-foreground">Priya M. - 1 month ago</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Related products */}
        <div className="mb-8">
          <h3 className="text-xl font-bold mb-4">Related Products</h3>
          <div className="grid grid-cols-2 gap-4">
            {relatedProducts.map((relatedProduct, idx) => (
              <motion.div
                key={relatedProduct.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Link href={`/products/${category}/${relatedProduct.id}`}>
                  <ProductCard product={relatedProduct} />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}


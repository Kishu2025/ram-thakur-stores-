"use client"

import { motion } from "framer-motion"
import { ArrowLeft, Mail, Phone, MapPin } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"

export default function AboutPage() {
  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 border-b border-border flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-2">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">About Us</h1>
        </div>
      </header>

      {/* Main content */}
      <main className="p-4">
        {/* Store intro */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Ram Thakur Stores</h2>
          <p className="text-muted-foreground mb-6">
            Your trusted partner for premium electronics and mobile phones since 2015. We pride ourselves on offering
            quality products with exceptional customer service.
          </p>
        </motion.div>

        {/* Our story */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h3 className="text-xl font-bold mb-4">Our Story</h3>
          <p className="text-muted-foreground mb-4">
            Ram Thakur Stores was founded with a vision to provide high-quality electronics at competitive prices. What
            started as a small shop has now grown into a trusted name in the electronics retail industry.
          </p>
          <p className="text-muted-foreground mb-4">
            We began our journey focusing on mobile phones and accessories, and have since expanded our product range to
            include laptops, tablets, smartwatches, and various electronic accessories.
          </p>
          <p className="text-muted-foreground">
            Currently, we operate as an offline store, providing personalized service to our valued customers. We're
            excited to announce that we'll soon be expanding to online services, bringing our products to customers
            nationwide.
          </p>
        </motion.div>

        {/* Founders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <h3 className="text-xl font-bold mb-4">Our Team</h3>
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 p-4 border border-border rounded-lg">
              <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-primary shrink-0">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG20250312162026.jpg-RpdlL8375MIGinweZZeTxGqUMXyXuU.jpeg"
                  alt="Founder"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2 text-center sm:text-left">Founder</h4>
                <p className="text-muted-foreground mb-4">
                  Our founder is a technology enthusiast with over 10 years of experience in the electronics retail
                  industry. His vision and leadership have been instrumental in establishing Ram Thakur Stores as a
                  trusted name in the market.
                </p>
                <p className="text-muted-foreground">
                  "Our goal is to make quality technology accessible to everyone and provide an exceptional shopping
                  experience for our customers."
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 p-4 border border-border rounded-lg">
              <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-primary shrink-0">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG20250209171541.jpg-Hd3vJZxkSpUmKj8DNuagXZrP4UVnwO.jpeg"
                  alt="Co-Founder"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h4 className="text-lg font-bold mb-2 text-center sm:text-left">Co-Founder</h4>
                <p className="text-muted-foreground mb-4">
                  Our co-founder brings expertise in customer experience and business operations. With a background in
                  retail management, he ensures that Ram Thakur Stores delivers exceptional service and maintains strong
                  relationships with suppliers.
                </p>
                <p className="text-muted-foreground">
                  "We believe in building lasting relationships with our customers through trust, quality products, and
                  personalized service."
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Store information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-8"
        >
          <h3 className="text-xl font-bold mb-4">Visit Our Store</h3>
          <div className="p-4 border border-border rounded-lg space-y-4">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Address</p>
                <p className="text-muted-foreground">123 Main Street, City Center, State - 123456</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Phone className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Phone</p>
                <p className="text-muted-foreground">+91 98765 43210</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Mail className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Email</p>
                <p className="text-muted-foreground">info@ramthakurstores.com</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Future plans */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <h3 className="text-xl font-bold mb-4">Future Plans</h3>
          <div className="p-4 border border-border rounded-lg">
            <p className="text-muted-foreground mb-4">
              We're excited to announce our upcoming expansion to online services. Soon, you'll be able to browse and
              purchase our products from the comfort of your home.
            </p>
            <p className="text-muted-foreground">Our online store will feature:</p>
            <ul className="list-disc list-inside text-muted-foreground mt-2 space-y-1">
              <li>Nationwide delivery</li>
              <li>Secure payment options</li>
              <li>Easy returns and exchanges</li>
              <li>Exclusive online deals</li>
              <li>Customer reviews and ratings</li>
            </ul>
          </div>
        </motion.div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}


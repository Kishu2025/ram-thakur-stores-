"use client"

import { motion } from "framer-motion"
import { User, Settings, ShoppingBag, Heart, LogOut, ChevronRight, CreditCard, HelpCircle, Bell } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ModeToggle } from "@/components/mode-toggle"

export default function AccountPage() {
  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 border-b border-border flex justify-between items-center">
        <h1 className="text-xl font-bold">My Account</h1>
        <ModeToggle />
      </header>

      {/* Main content */}
      <main className="p-4">
        {/* Profile section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 p-4 mb-6 border border-border rounded-lg"
        >
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h2 className="font-bold text-lg">Guest User</h2>
            <p className="text-muted-foreground">Sign in to access your account</p>
          </div>
          <Button className="ml-auto">Sign In</Button>
        </motion.div>

        {/* Account sections */}
        <div className="space-y-6">
          <AccountSection
            title="Orders & Purchases"
            items={[
              { icon: ShoppingBag, label: "My Orders", link: "/account/orders" },
              { icon: CreditCard, label: "Payment Methods", link: "/account/payments" },
            ]}
          />

          <AccountSection
            title="Profile Settings"
            items={[
              { icon: User, label: "Personal Information", link: "/account/profile" },
              { icon: Settings, label: "Account Settings", link: "/account/settings" },
              { icon: Bell, label: "Notifications", link: "/account/notifications" },
            ]}
          />

          <AccountSection
            title="My Activities"
            items={[
              { icon: Heart, label: "Wishlist", link: "/account/wishlist" },
              { icon: HelpCircle, label: "Help & Support", link: "/account/support" },
            ]}
          />

          <div className="pt-4">
            <Button variant="outline" className="w-full" size="lg">
              <LogOut className="h-4 w-4 mr-2" /> Sign Out
            </Button>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

function AccountSection({ title, items }) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
      <h3 className="font-bold mb-3">{title}</h3>
      <div className="border border-border rounded-lg overflow-hidden">
        {items.map((item, idx) => (
          <Link key={idx} href={item.link}>
            <div
              className={`flex items-center justify-between p-4 hover:bg-accent transition-colors ${idx !== 0 ? "border-t border-border" : ""}`}
            >
              <div className="flex items-center gap-3">
                <item.icon className="h-5 w-5 text-primary" />
                <span>{item.label}</span>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </div>
          </Link>
        ))}
      </div>
    </motion.div>
  )
}


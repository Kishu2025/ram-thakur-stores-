"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Search, X } from "lucide-react"
import Link from "next/link"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { ProductCard } from "@/components/product-card"
import { productData } from "@/lib/product-data"

export default function SearchPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [recentSearches, setRecentSearches] = useState(["iPhone", "Samsung", "Headphones", "Laptop", "Charger"])
  const [popularSearches] = useState([
    "Realme 13 Pro",
    "Samsung Galaxy",
    "Apple Watch",
    "Power Bank",
    "Wireless Earbuds",
  ])

  useEffect(() => {
    if (searchTerm.trim() === "") {
      setSearchResults([])
      return
    }

    // Search across all categories
    const results = []
    Object.keys(productData).forEach((category) => {
      const matchingProducts = productData[category].filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (product.description && product.description.toLowerCase().includes(searchTerm.toLowerCase())),
      )
      results.push(
        ...matchingProducts.map((product) => ({
          ...product,
          category,
        })),
      )
    })

    setSearchResults(results)
  }, [searchTerm])

  const handleSearch = (term) => {
    setSearchTerm(term)

    // Add to recent searches if not already there
    if (term.trim() !== "" && !recentSearches.includes(term)) {
      setRecentSearches((prev) => [term, ...prev.slice(0, 4)])
    }
  }

  const clearSearch = () => {
    setSearchTerm("")
    setSearchResults([])
  }

  return (
    <div className="min-h-screen pb-16">
      {/* Header with search */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search products, brands, and more..."
            className="pl-10 pr-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <button className="absolute right-3 top-1/2 transform -translate-y-1/2" onClick={clearSearch}>
              <X className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
        </div>
      </header>

      {/* Main content */}
      <main className="p-4">
        {searchResults.length > 0 ? (
          <div>
            <h2 className="text-lg font-bold mb-4">Search Results ({searchResults.length})</h2>
            <div className="grid grid-cols-2 gap-4">
              {searchResults.map((product, idx) => (
                <motion.div
                  key={`${product.category}-${product.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                >
                  <Link href={`/products/${product.category}/${product.id}`}>
                    <ProductCard product={product} />
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        ) : (
          <div>
            {/* Recent searches */}
            <div className="mb-8">
              <h2 className="text-lg font-bold mb-4">Recent Searches</h2>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((term, idx) => (
                  <Button key={idx} variant="outline" size="sm" onClick={() => handleSearch(term)}>
                    {term}
                  </Button>
                ))}
              </div>
            </div>

            {/* Popular searches */}
            <div className="mb-8">
              <h2 className="text-lg font-bold mb-4">Popular Searches</h2>
              <div className="flex flex-wrap gap-2">
                {popularSearches.map((term, idx) => (
                  <Button key={idx} variant="outline" size="sm" onClick={() => handleSearch(term)}>
                    {term}
                  </Button>
                ))}
              </div>
            </div>

            {/* Popular categories */}
            <div>
              <h2 className="text-lg font-bold mb-4">Browse Categories</h2>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { name: "Mobile Phones", link: "/products/mobile" },
                  { name: "Laptops", link: "/products/laptops" },
                  { name: "Accessories", link: "/products/accessories" },
                  { name: "Smartwatches", link: "/products/smartwatches" },
                ].map((category, idx) => (
                  <Link key={idx} href={category.link}>
                    <div className="border border-border rounded-lg p-4 text-center hover:bg-accent transition-colors">
                      <h3 className="font-medium">{category.name}</h3>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}


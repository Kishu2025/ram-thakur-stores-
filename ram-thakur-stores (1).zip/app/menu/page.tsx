"use client"

import { motion } from "framer-motion"
import {
  Phone,
  Tablet,
  Laptop,
  Headphones,
  Watch,
  ShoppingBag,
  User,
  Home,
  Search,
  Info,
  Mail,
  MapPin,
  Clock,
  ChevronRight,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { BottomNav } from "@/components/bottom-nav"
import { ModeToggle } from "@/components/mode-toggle"

export default function MenuPage() {
  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md p-4 border-b border-border flex justify-between items-center">
        <h1 className="text-xl font-bold">Menu</h1>
        <ModeToggle />
      </header>

      {/* Main content */}
      <main className="p-4">
        {/* Store logo and name */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center mb-8"
        >
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <ShoppingBag className="h-12 w-12 text-primary" />
          </div>
          <h2 className="text-2xl font-bold">Ram Thakur Stores</h2>
          <p className="text-muted-foreground">Premium Electronics Store</p>
        </motion.div>

        {/* All categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h3 className="font-bold mb-3">All Categories</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: Phone, label: "Mobile Phones", link: "/products/mobile" },
              { icon: Tablet, label: "Tablets", link: "/products/tablets" },
              { icon: Laptop, label: "Laptops", link: "/products/laptops" },
              { icon: Headphones, label: "Accessories", link: "/products/accessories" },
              { icon: Watch, label: "Smartwatches", link: "/products/smartwatches" },
            ].map((item, idx) => (
              <Link key={idx} href={item.link}>
                <div className="border border-border rounded-lg p-4 hover:bg-accent transition-colors flex flex-col items-center text-center">
                  <item.icon className="h-6 w-6 text-primary mb-2" />
                  <span>{item.label}</span>
                </div>
              </Link>
            ))}
          </div>
        </motion.div>

        {/* Quick links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <h3 className="font-bold mb-3">Quick Links</h3>
          <div className="border border-border rounded-lg overflow-hidden">
            {[
              { icon: Home, label: "Home", link: "/" },
              { icon: Search, label: "Search", link: "/search" },
              { icon: ShoppingBag, label: "Products", link: "/products" },
              { icon: User, label: "Account", link: "/account" },
              { icon: Info, label: "About Us", link: "/about" },
            ].map((item, idx) => (
              <Link key={idx} href={item.link}>
                <div
                  className={`flex items-center justify-between p-4 hover:bg-accent transition-colors ${idx !== 0 ? "border-t border-border" : ""}`}
                >
                  <div className="flex items-center gap-3">
                    <item.icon className="h-5 w-5 text-primary" />
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
            ))}
          </div>
        </motion.div>

        {/* Store information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-8"
        >
          <h3 className="font-bold mb-3">Store Information</h3>
          <div className="border border-border rounded-lg p-4 space-y-4">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Address</p>
                <p className="text-muted-foreground">123 Main Street, City Center, State - 123456</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Store Hours</p>
                <p className="text-muted-foreground">Monday - Saturday: 10:00 AM - 8:00 PM</p>
                <p className="text-muted-foreground">Sunday: 11:00 AM - 6:00 PM</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Mail className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Contact</p>
                <p className="text-muted-foreground">Email: info@ramthakurstores.com</p>
                <p className="text-muted-foreground">Phone: +91 98765 43210</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Founders section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <h3 className="font-bold mb-3">Our Team</h3>
          <div className="grid grid-cols-2 gap-3">
            <Link href="/about">
              <div className="border border-border rounded-lg p-4 hover:bg-accent transition-colors flex flex-col items-center text-center">
                <div className="relative w-16 h-16 rounded-full overflow-hidden border-2 border-primary mb-2">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG20250312162026.jpg-RpdlL8375MIGinweZZeTxGqUMXyXuU.jpeg"
                    alt="Founder"
                    fill
                    className="object-cover"
                  />
                </div>
                <span className="font-medium">Founder</span>
              </div>
            </Link>

            <Link href="/about">
              <div className="border border-border rounded-lg p-4 hover:bg-accent transition-colors flex flex-col items-center text-center">
                <div className="relative w-16 h-16 rounded-full overflow-hidden border-2 border-primary mb-2">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG20250209171541.jpg-Hd3vJZxkSpUmKj8DNuagXZrP4UVnwO.jpeg"
                    alt="Co-Founder"
                    fill
                    className="object-cover"
                  />
                </div>
                <span className="font-medium">Co-Founder</span>
              </div>
            </Link>
          </div>
        </motion.div>
      </main>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}

